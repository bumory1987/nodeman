

// require('core-js')

const array_flatted = [1 ,[2,3,] ]
const flatman = array_flatted.flat()
// console.log(flatman)


const orginal = 'abcabc123'
// const changed = orginal.replaceAll('abc', '123')
// console.log(changed)

function sleepMan(duration){
    return new Promise((resovle, reject)=> {
        setTimeout(()=>{
            try{
                resovle(duration)
            }catch(Error){
                reject(duration)  
            }
       
        }, duration)
    })
}


const alwaysfail = () =>{
    return new Promise((resolve, reject)=>{
        reject("oh my god")
    })
}


Promise.allSettled([
    sleepMan(2000),
    sleepMan(1000),
    sleepMan(3000),
    alwaysfail(),
    sleepMan(1000),
    sleepMan(1500),
    sleepMan(2500)
    ]
).then((value)=>{
    console.log(value)
    console.log('finish')})