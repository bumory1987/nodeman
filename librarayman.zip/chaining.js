//es build use// 

const obj = [
    {
        foo: {
            bar: {
                baz : 1 
            }
        }
    },
    {},
    {  
        foo: {
            bar: {}
        }
    },
    {   
        foo: {}
    }
]

// console.log(obj.map(obj => {
//     const {foo} = obj
//     if(foo){
//         const {bar} = foo
//         if(bar){
//             return foo.bar
//         }
//         return undefined
//     }
//     return undefined
// }))


//optional Chaining!!
console.log(obj.map(obj => obj.foo?.bar?.baz))