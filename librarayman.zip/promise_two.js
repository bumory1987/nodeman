const fs = require('fs')

// fs.readFile('../.gitignore', 'utf-8' , (error, value)=> {
//     console.log(value)
// } )




function readMan(fileName){
    return new Promise((resolve, reject)=> {
        fs.readFile(fileName, 'utf-8', (error, value) => {
            if(error){
                reject(error)
            }else{
                resolve(value)
            }
        })
    })
}


async function testMain(){
    const result = await fs.promises.readFile('../.gitignore', 'utf-8')
    
    console.log(result)
}


// readMan('../.gitignore').then((value)=> console.log(value))

// fs.promises.readFile('../.gitignore', 'utf-8').then(value => console.log(value))


const ohmyogd =1 

async function sleepMan(duration){
    return new Promise((resolve, reject)=>{
        setTimeout(()=> {
            resolve(ohmyogd)
        }, duration)
    })
 
} 


async function main(){
    console.log('first')
    await sleepMan(1000)
    console.log('second')
    await sleepMan(1000)
    console.log('third')
    await sleepMan(1000)
}


async function mainOther(){
    console.log('first')
    sleepMan(1000)
    console.log('second')
    sleepMan(1000)
    console.log('third')
    sleepMan(1000)
}

testMain()