const ary = [1,2,3,4,5]

const [head, ...rest] = ary

console.log(head, rest )
console.log(head)
console.log(...rest)



const personalData = {
    nickname: 'JH',
    email : 'sung@gmgmgm.com'
} 

const publicData = {
    age : 22 
}


const override = {
    nickname: 'foo',
}

const shouldOverride = true

const user ={
    ...publicData, 
    ...{
        nickname: 'JH',
        email : 'sung@gmgmgm.com'
    },
    ...(shouldOverride ? {
        nickname: 'foo'
    } : null )
}

console.log(user)

