// @ts-check
// Formatting, Linting

/* eslint-disable-next-line no-console */
console.log("hello world!")

const x = 1
/* eslint-disable-next-line no-console */
console.log(x)

const someString = "hell"
const result = Math.log(someString)
console.log(result)
