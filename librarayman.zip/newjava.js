const personalData = {
    nickname: 'JH',
    email : 'sung@gmgmgm.com'
} 

const publicData = {
    age : 22 
}

const user ={
    ...personalData, 
    ...publicData
}

console.log(user)