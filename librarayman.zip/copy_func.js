const people = [
    {
        age: 20,
        category: 'a',
        city: 'seoul',
        pet: ['cat', 'dog']
    },
    {
        age: 22,
        category: 'a',
        city: 'busan',
    },
    {
        age: 31,
        category: 'a',
        city: 'daegu',
        pet: ['cat', 'dog']
    },
    {
        age: 36,
        category: 'b',
        city: 'seoul',
    },
    {
        age: 27,
        category: 'b',
        city: 'seoul',
        pet: 'cat'
    },
    {
        age: 24,
        category: 'a',
        city: 'seoul',
        pet: 'dog'
    }
]


function solveA(){
    /** @type {string[]} */
    const cities = [] 

    for (const person of people){
        if(person.age< 30 ){
            if(!cities.find((city) => person.city === city)){
                cities.push(person.city)
            }
        }
    }
    return cities
}

// console.log("A -> ", solveA() )



function solveFunc(){

    const allCities = people.filter(( {age} ) => age< 30 ).map(({city}) => city)
    const setCities = new Set(allCities) 
    return Array.from(setCities)

}

// console.log("B -> ", solveFunc() )


// 각 도시별로 개와 고양이를 키우는 사람의 수  




function recursiveman( dataStru, keyman ){
    if(keyman.length == 0 ){
        return dataStru
    }else{
       const head = keyman[0]
       const noHead = keyman.shift() 
       const reStructure = buildStructure(dataStru, head)
       const standard = Object.keys(reStructure)
       const totalStructure = {}
       standard.map((item) =>  {
        totalStructure[item] = recursiveman(reStructure[item],keyman )

       }  ) 
       return totalStructure
       
    } 
}



function buildStructure(struc, defineKeys){
    return struc.reduce((pre, cur) => 
    {
        if(pre[cur[defineKeys]] === undefined){
           pre[cur[defineKeys]] = [cur]
        }else{
           pre[cur[defineKeys]].push(cur)
        }
        return pre
    } , {} )
} 


//const combine =recursiveman(people, ['city', 'category'])

//console.log(combine['seoul'])

// console.log([] instanceof Array)




// function solveModern(){
//     return people.map( ({ city, pet: petOrPets}) => {
//         const pets = (typeof petOrPets === 'string' ? [petOrPets] : petOrPets) || []
//         return {
//             city,
//             pets
//         } 
//     }).map( ({city, pets}) =>  { 
//         return pets.map((pet) => { 
//             return [city, pet]
//         } )          
//     }).reduce((pre, cur) => [...pre, ...cur], []).reduce(
//         (pre, cur) => { 
//             // console.log(pre)
//             const first = pre[cur[0]] || {}
//             const num = first[cur[1]] || 0 
//             first[cur[1]] = num + 1 
//             pre[cur[0]] = first
//             return pre
//             // const num = pre[cur[0]][cur[1]] || 0 
//             // pre[cur[0]][cur[1]] = num + 1 
//         } , {}) 

// }



function solveModern(){
    return people.map( ({ city, pet: petOrPets}) => {
        const pets = (typeof petOrPets === 'string' ? [petOrPets] : petOrPets) || []
        return {
            city,
            pets
        } 
    }).flatMap( ({city, pets}) =>  { 
        return pets.map((pet) => { 
            return [city, pet]
        } )          
    }).reduce((result, [city, pet]) => {
        if(!city || !pet){
            return result
        }
        return {
            ...result, 
            [city]:{
                ...result[city],
                [pet] : (result[city]?.[pet] || 0) +1
            },
        }
    } ,{})

}




console.log(solveModern())



// const arrayInstructions = {
//     'm': 5,
//     's': 5,
//     'p': 5
//   }



// const deck = [].concat.apply([], Object.keys(arrayInstructions).map(function(k) { 
//     return new Array(arrayInstructions[k]).fill(k) 
// }));
// console.log(deck)


// const checkman =[[1], [2,3], [4,5]].reduce((pre, cur ) => { return  [...pre, ...cur] }, [])
// console.log(checkman)