// @ts-check

/* eslint-disable no-new */
/* eslint-disable no-console */

// new Promise((resovle, reject)=> {
//     console.log("Inside Promise")
//     reject(new Error("First Error"))
//     resovle('First resolve')
// }).catch((error)=> {
//     console.log('error', error)
// }).then(value => {
//     console.log("Inside First Then")
//     console.log(value)
// })


// new Promise((resovle, reject)=> {
//     console.log("Inside Promise")
//     resovle('First resolve')
// }).then(value => {
//     console.log("Inside First Then")
//     console.log(value)
// }).catch((error)=> {
//     console.log('error', error)
// })





// new Promise((resolve, reject)=> {
//     console.log('Before time out')
//     setTimeout(()=> {
//         resolve(Math.random())
//         console.log('After resolve')
//     }, 1000)
// } ).then((value) => {
//     console.log('then first')
//     console.log('value = ', value)
//     return value
// }).then((item)=> {
//     console.log('then second')
//     console.log('tiem = ', item)
// }).then(()=> {
//     console.log('finally')
// })

function returnPromiseForTimeout(){
    return new Promise((resolve, reject)=> {
        setTimeout(()=> {
            resolve(Math.random())
        }, 1000)
    } )
}



returnPromiseForTimeout().then((value) => {
    console.log('then first')
    console.log('value = ', value)
    return returnPromiseForTimeout()
}).then((item)=> {
    console.log('then second')
    console.log('tiem = ', item)
    return returnPromiseForTimeout()
}).then((item)=> {
    console.log('finally')
    console.log('tiem = ', item)
    return returnPromiseForTimeout()
})



setTimeout(()=> {
    const value = Math.random()
    console.log(value)
    setTimeout(()=> {
        const value = Math.random()
        console.log(value)
    }, 500)

}, 500)


